import {useAuth} from '../context/AuthContext'
//import {profile} from '../api/auth'

function Perfil() {

    //const {perfil} = useAuth();

    /*try{
    const datosUsuario = verPerfil();
    console.log(datosUsuario.data);
    }

    catch (error){
        console.log('El usuario no se ha podido encontrar');
        console.log(error);
    }*/
    return (  
    <div>
        <h1>
            Datos del usuario
        </h1>
    </div>
    )
}

export default Perfil